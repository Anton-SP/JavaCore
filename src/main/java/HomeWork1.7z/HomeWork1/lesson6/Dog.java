package HomeWork1.lesson6;

public class Dog extends Animal {
    final int RUNMAX = 500;
    final int SWIMMAX = 10;


    @Override
    void swim(int distance) {
        if (distance <= this.SWIMMAX) {
            System.out.printf("Собака по кличке %s проплыла %d метров.%n%n ", this.name, distance);
        } else {
            System.out.printf("Собака по кличке %s проплыла только %d метров.%n%n ", this.name, SWIMMAX);

        }
    }

    @Override
    void run(int distance) {
        if (distance <= this.RUNMAX) {
            System.out.printf("Собака по кличке %s пробежала %d метров.%n%n ", this.name, distance);
        } else {
            System.out.printf("Собака по кличке %s пробежала только %d метров.%n%n ", this.name, RUNMAX);

        }
    }

    public Dog(String name) {
        super(name);
    }
}