package HomeWork1.lesson6;

import java.util.Scanner;

public class PetShow {
    private Dog[] dogs;
    private Cat[] cats;
    int dogCount = 0;
    int catCount = 0;
    int animalsCount = 0;
    int maxDog;
    int maxCat;


    public PetShow(int maxCat, int maxDog) {
        dogs = new Dog[maxDog];
        cats = new Cat[maxCat];
        this.maxDog = maxDog;
        this.maxCat = maxCat;
    }

    public int getDogCount() {
        return dogCount;
    }


    public int getCatCount() {
        return catCount;
    }


    public int getAnimalsCount() {
        return animalsCount;
    }


    public boolean addDog() {
        if (maxDog > dogCount) {
            String dogName = "Шарик";//имя по умолчанию
            System.out.println("Введите кличку собаки");
            Scanner in = new Scanner(System.in);
            if (in.hasNext()) {
                dogs[dogCount] = new Dog(dogName = in.nextLine());
                dogCount++;
                animalsCount++;
                return true;
            } else {//ветка по сути не нужна т.к. переделал проверку на не пустой ввод, но оставил на всякий если критерий изменится
                System.out.println("Извините вы ввели неверное значение будет использована кличка по умолчанию");
                dogs[dogCount] = new Dog(dogName);
                dogCount++;
                animalsCount++;
                return true;

            }
        } else {
            System.out.println("Извините нет свободной конуры некуда поселить пёсика");
            return false;
        }
    }

    public boolean addCat() {

        if (maxCat > catCount) {
            String catName = "Барсик";//имя по умолчанию
            System.out.println("Введите кличку кошки");
            Scanner in = new Scanner(System.in);
            if (in.hasNext()) {
                cats[catCount] = new Cat(catName = in.nextLine());
                catCount++;
                animalsCount++;
                return true;
            } else {
                System.out.println("Извините вы ввели неверное значение будет использована кличка по умолчанию");
                cats[catCount] = new Cat(catName);
                catCount++;
                animalsCount++;
                return true;

            }
        } else {
            System.out.println("Извините нет свободной коробки, котику некуда прилечь");
            return false;
        }
    }

    public Cat[] getCats() {
        return cats;
    }

    public Dog[] getDogs() {
        return dogs;
    }


}
