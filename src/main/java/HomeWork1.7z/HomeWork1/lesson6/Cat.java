package HomeWork1.lesson6;

public class Cat extends Animal {
    final int RUNMAX = 200;

    public Cat(String animalName) {
        super(animalName);
    }


    @Override
    void swim(int distance) {
        System.out.printf("Кошка по кличке %s умеет плавать! Но не хочет.%n", this.name);
    }

    @Override
    void run(int distance) {
        if (distance <= this.RUNMAX) {
            System.out.printf("Кошка по кличке %s пробежала %d метров.%n%n ", this.name, distance);
        } else {
            System.out.printf("Кошка по кличке %s пробежала только %d метров.%n%n ", this.name, RUNMAX);
        }
    }
}

