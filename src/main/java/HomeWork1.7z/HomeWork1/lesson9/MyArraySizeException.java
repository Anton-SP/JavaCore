package HomeWork1.lesson9;

public class MyArraySizeException  extends ArrayIndexOutOfBoundsException{
    public MyArraySizeException(String s) {
        super(s);
    }
}
