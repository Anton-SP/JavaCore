package HomeWork1.lesson8;

public interface Participants  {
int getJump();
int getRun();
String getName();
void jump();
void run();
void fall();
boolean getStatus();
}
