package HomeWork1.lesson8;

public interface Obstacles {
void info();

void overcomeAnObstacle(Participants participant);

}
