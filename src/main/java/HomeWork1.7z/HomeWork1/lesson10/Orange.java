package HomeWork1.lesson10;

public class Orange extends Fruit {
    public Orange() {
        super(1.5f);
    }

    @Override
    public void draw() {
        System.out.print('Ⓞ' + " "); //apple
    }
}
