package HomeWork1.lesson10;

public class Apple extends Fruit {


    public Apple() {
        super(1.0f);
    }

    @Override
    public void draw() {
        System.out.print('Ⓐ'+" "); //apple
    }
}
